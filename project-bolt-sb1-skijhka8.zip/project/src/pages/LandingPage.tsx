import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Wand2 } from 'lucide-react';

export const LandingPage: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      navigate('/builder', { state: { prompt } });
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex items-center justify-center">
      <div className="w-full max-w-2xl px-4">
        <div className="text-center mb-12">
          <Wand2 className="w-16 h-16 mx-auto mb-6 text-purple-500" />
          <h1 className="text-4xl font-bold mb-4">Website Builder AI</h1>
          <p className="text-xl text-gray-400">
            Describe your dream website and let AI bring it to life
          </p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe your website (e.g., 'Create a modern portfolio website with a dark theme...')"
              className="w-full h-32 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
            />
          </div>
          <button
            type="submit"
            className="w-full py-3 px-6 bg-purple-600 hover:bg-purple-700 rounded-lg font-medium transition-colors"
          >
            Generate Website
          </button>
        </form>
      </div>
    </div>
  );
};