import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Editor from '@monaco-editor/react';
import { FileExplorer } from '../components/FileExplorer';
import { StepsList } from '../components/StepsList';
import { FileNode, Step } from '../types';

export const BuilderPage: React.FC = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<'code' | 'preview'>('code');
  const [selectedFileContent, setSelectedFileContent] = useState('');
  const [files, setFiles] = useState<FileNode[]>([
    {
      name: 'src',
      type: 'folder',
      isOpen: true,
      children: [
        {
          name: 'App.tsx',
          type: 'file',
          content: 'export default function App() {\n  return <div>Hello World</div>;\n}'
        },
        {
          name: 'components',
          type: 'folder',
          isOpen: false,
          children: []
        }
      ]
    }
  ]);

  const [steps] = useState<Step[]>([
    {
      id: 1,
      title: 'Initialize Project',
      description: 'Setting up the basic project structure',
      completed: true
    },
    {
      id: 2,
      title: 'Create Components',
      description: 'Building the necessary React components',
      completed: false
    }
  ]);

  const handleFileSelect = (content: string) => {
    setSelectedFileContent(content);
  };

  const handleToggleFolder = (path: string[]) => {
    const toggleNode = (nodes: FileNode[], currentPath: string[]): FileNode[] => {
      return nodes.map(node => {
        if (node.name === currentPath[0]) {
          if (currentPath.length === 1) {
            return { ...node, isOpen: !node.isOpen };
          }
          return {
            ...node,
            children: node.children ? toggleNode(node.children, currentPath.slice(1)) : []
          };
        }
        return node;
      });
    };
    
    setFiles(toggleNode(files, path));
  };

  return (
    <div className="h-screen bg-gray-900 text-gray-200 flex">
      <div className="w-1/4 border-r border-gray-700">
        <StepsList steps={steps} onStepClick={() => {}} />
      </div>
      
      <div className="w-1/4 border-r border-gray-700">
        <FileExplorer
          files={files}
          onFileSelect={handleFileSelect}
          onToggleFolder={handleToggleFolder}
        />
      </div>
      
      <div className="w-1/2 flex flex-col">
        <div className="flex border-b border-gray-700">
          <button
            className={`px-4 py-2 ${
              activeTab === 'code' ? 'bg-gray-800 text-white' : 'text-gray-400'
            }`}
            onClick={() => setActiveTab('code')}
          >
            Code
          </button>
          <button
            className={`px-4 py-2 ${
              activeTab === 'preview' ? 'bg-gray-800 text-white' : 'text-gray-400'
            }`}
            onClick={() => setActiveTab('preview')}
          >
            Preview
          </button>
        </div>
        
        <div className="flex-1">
          {activeTab === 'code' ? (
            <Editor
              height="100%"
              defaultLanguage="typescript"
              theme="vs-dark"
              value={selectedFileContent}
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                readOnly: true
              }}
            />
          ) : (
            <iframe
              title="preview"
              className="w-full h-full bg-white"
              srcDoc={`
                <!DOCTYPE html>
                <html>
                  <body>
                    <div id="root"></div>
                    <script type="module">
                      ${selectedFileContent}
                    </script>
                  </body>
                </html>
              `}
            />
          )}
        </div>
      </div>
    </div>
  );
};