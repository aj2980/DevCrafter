export interface FileNode {
  name: string;
  type: 'file' | 'folder';
  content?: string;
  children?: FileNode[];
  isOpen?: boolean;
}

export interface Step {
  id: number;
  title: string;
  description: string;
  completed: boolean;
}